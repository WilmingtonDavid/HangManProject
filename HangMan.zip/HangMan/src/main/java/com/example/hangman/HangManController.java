package com.example.hangman;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

import java.util.*;


public class HangManController {

    /* This method will generate the random word/hint for the game.*/
    public static String[] generateString(){
        String[] finalArray = new String[2];
        HashMap<String, String> wordDictionary = new HashMap<String, String>();

        //Start Dictionary (Put words and hints inside here please. Words should be all caps.)
        wordDictionary.put("ANTEATER", " An insect that lives in colonies ");
        wordDictionary.put("WOOD", " Used to build things ");

        //End Dictionary

        Object[] keys = wordDictionary.keySet().toArray();
        Object key = keys[new Random().nextInt(keys.length)];

        List<Map.Entry<String,String>> list = new ArrayList<Map.Entry<String, String>>(wordDictionary.entrySet());
        Collections.shuffle(list);


        for (Map.Entry<String, String> entry : list) {
            finalArray[0] = entry.getKey();
            finalArray[1] = entry.getValue();

            // Returns an array with the word in the 0 index, and the hint at the 1 index.
            return finalArray;
        }
        return null;
    }

    /* This method will create the first placeholder. It will be a character array filled with dashes.*/
    public static char[] generatePlaceHolder(String wordToGuess){
        char[] placeHolderArray = new char[wordToGuess.length()];

        for(int i = 0; i < wordToGuess.length(); i++){
            placeHolderArray[i] = '-';
        }
        return placeHolderArray;
    }

    /* This method will compare the current char array to the word to guess, and if the word to guess contains
       the letter being guessed, it will be placed in the current char array.*/
    public static char[] checkGuess(String wordToGuess, char letterToGuess, char[] currentPlaceHolder){
        for(int i = 0; i < wordToGuess.length(); i++){
            if(wordToGuess.charAt(i) == letterToGuess){
                currentPlaceHolder[i] = letterToGuess;
            }
        }
        return currentPlaceHolder;
    }

    @FXML
    private ImageView finalDeathImage;

    @FXML
    private ProgressBar progressBarField;

    @FXML
    private TextField wordToGuessTextField;

    @FXML
    void giveHintOnPress(ActionEvent event) {

    }

    @FXML
    void letterAOnPress(ActionEvent event) {

    }

    @FXML
    void letterBOnPress(ActionEvent event) {

    }

    @FXML
    void letterCOnPress(ActionEvent event) {

    }

    @FXML
    void letterDOnPress(ActionEvent event) {

    }

    @FXML
    void letterEOnPress(ActionEvent event) {

    }

    @FXML
    void letterFOnPress(ActionEvent event) {

    }

    @FXML
    void letterGOnPress(ActionEvent event) {

    }

    @FXML
    void letterHOnPress(ActionEvent event) {

    }

    @FXML
    void letterIOnPress(ActionEvent event) {

    }

    @FXML
    void letterJOnPress(ActionEvent event) {

    }

    @FXML
    void letterKOnPress(ActionEvent event) {

    }

    @FXML
    void letterLOnPress(ActionEvent event) {

    }

    @FXML
    void letterMOnPress(ActionEvent event) {

    }

    @FXML
    void letterNOnPress(ActionEvent event) {

    }

    @FXML
    void letterOOnPress(ActionEvent event) {

    }

    @FXML
    void letterPOnPress(ActionEvent event) {

    }

    @FXML
    void letterQOnPress(ActionEvent event) {

    }

    @FXML
    void letterROnPress(ActionEvent event) {

    }

    @FXML
    void letterSOnPress(ActionEvent event) {

    }

    @FXML
    void letterTOnPress(ActionEvent event) {

    }

    @FXML
    void letterUOnPress(ActionEvent event) {

    }

    @FXML
    void letterVOnPress(ActionEvent event) {

    }

    @FXML
    void letterWOnPress(ActionEvent event) {

    }

    @FXML
    void letterXOnPress(ActionEvent event) {

    }

    @FXML
    void letterYOnPress(ActionEvent event) {

    }

    @FXML
    void letterZOnPress(ActionEvent event) {

    }

    @FXML
    void newGameOnPress(ActionEvent event) {

    }

    public void initialize(){

    }

}
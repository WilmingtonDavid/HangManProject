package com.example.hangman;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

import java.util.*;


public class HangManController {

    // This method will generate the random word/hint for the game.
    public static String[] generateString(){
        String[] finalArray = new String[2];
        HashMap<String, String> wordDictionary = new HashMap<String, String>();

        //Start Dictionary (Put words and hints inside here please)
        wordDictionary.put("Ant", " An insect that lives in colonies ");
        wordDictionary.put("Wood", " Used to build things ");

        //End Dictionary

        Object[] keys = wordDictionary.keySet().toArray();
        Object key = keys[new Random().nextInt(keys.length)];

        List<Map.Entry<String,String>> list = new ArrayList<Map.Entry<String, String>>(wordDictionary.entrySet());
        Collections.shuffle(list);


        for (Map.Entry<String, String> entry : list) {
            finalArray[0] = entry.getKey();
            finalArray[1] = entry.getValue();
            
            // Returns an array with the word in the 0 index, and the hint at the 1 index.
            return finalArray;
        }
        return null;
    }

    @FXML
    private ImageView finalDeathImage;

    @FXML
    private ProgressBar progressBarField;

    @FXML
    private TextField wordToGuessTextField;

    @FXML
    void giveHintOnPress(ActionEvent event) {

    }

    @FXML
    void letterAOnPress(ActionEvent event) {

    }

    @FXML
    void letterBOnPress(ActionEvent event) {

    }

    @FXML
    void letterCOnPress(ActionEvent event) {

    }

    @FXML
    void letterDOnPress(ActionEvent event) {

    }

    @FXML
    void letterEOnPress(ActionEvent event) {

    }

    @FXML
    void letterFOnPress(ActionEvent event) {

    }

    @FXML
    void letterGOnPress(ActionEvent event) {

    }

    @FXML
    void letterHOnPress(ActionEvent event) {

    }

    @FXML
    void letterIOnPress(ActionEvent event) {

    }

    @FXML
    void letterJOnPress(ActionEvent event) {

    }

    @FXML
    void letterKOnPress(ActionEvent event) {

    }

    @FXML
    void letterLOnPress(ActionEvent event) {

    }

    @FXML
    void letterMOnPress(ActionEvent event) {

    }

    @FXML
    void letterNOnPress(ActionEvent event) {

    }

    @FXML
    void letterOOnPress(ActionEvent event) {

    }

    @FXML
    void letterPOnPress(ActionEvent event) {

    }

    @FXML
    void letterQOnPress(ActionEvent event) {

    }

    @FXML
    void letterROnPress(ActionEvent event) {

    }

    @FXML
    void letterSOnPress(ActionEvent event) {

    }

    @FXML
    void letterTOnPress(ActionEvent event) {

    }

    @FXML
    void letterUOnPress(ActionEvent event) {

    }

    @FXML
    void letterVOnPress(ActionEvent event) {

    }

    @FXML
    void letterWOnPress(ActionEvent event) {

    }

    @FXML
    void letterXOnPress(ActionEvent event) {

    }

    @FXML
    void letterYOnPress(ActionEvent event) {

    }

    @FXML
    void letterZOnPress(ActionEvent event) {

    }

    @FXML
    void newGameOnPress(ActionEvent event) {

    }

    public void initialize(){
        String[] wordAndHint = generateString();
        String wordToGuess = wordAndHint[0];
        String hintForWord = wordAndHint[1];

        wordToGuessTextField.setText(wordToGuess);

    }

}
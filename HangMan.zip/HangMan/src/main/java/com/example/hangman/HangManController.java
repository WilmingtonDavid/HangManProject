package com.example.hangman;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

public class HangManController {

    @FXML
    private ImageView finalDeathImage;

    @FXML
    private ProgressBar progressBarField;

    @FXML
    private TextField wordToGuessTextField;

    @FXML
    void giveHintOnPress(ActionEvent event) {

    }

    @FXML
    void letterAOnPress(ActionEvent event) {

    }

    @FXML
    void letterBOnPress(ActionEvent event) {

    }

    @FXML
    void letterCOnPress(ActionEvent event) {

    }

    @FXML
    void letterDOnPress(ActionEvent event) {

    }

    @FXML
    void letterEOnPress(ActionEvent event) {

    }

    @FXML
    void letterFOnPress(ActionEvent event) {

    }

    @FXML
    void letterGOnPress(ActionEvent event) {

    }

    @FXML
    void letterHOnPress(ActionEvent event) {

    }

    @FXML
    void letterIOnPress(ActionEvent event) {

    }

    @FXML
    void letterJOnPress(ActionEvent event) {

    }

    @FXML
    void letterKOnPress(ActionEvent event) {

    }

    @FXML
    void letterLOnPress(ActionEvent event) {

    }

    @FXML
    void letterMOnPress(ActionEvent event) {

    }

    @FXML
    void letterNOnPress(ActionEvent event) {

    }

    @FXML
    void letterOOnPress(ActionEvent event) {

    }

    @FXML
    void letterPOnPress(ActionEvent event) {

    }

    @FXML
    void letterQOnPress(ActionEvent event) {

    }

    @FXML
    void letterROnPress(ActionEvent event) {

    }

    @FXML
    void letterSOnPress(ActionEvent event) {

    }

    @FXML
    void letterTOnPress(ActionEvent event) {

    }

    @FXML
    void letterUOnPress(ActionEvent event) {

    }

    @FXML
    void letterVOnPress(ActionEvent event) {

    }

    @FXML
    void letterWOnPress(ActionEvent event) {

    }

    @FXML
    void letterXOnPress(ActionEvent event) {

    }

    @FXML
    void letterYOnPress(ActionEvent event) {

    }

    @FXML
    void letterZOnPress(ActionEvent event) {

    }

    @FXML
    void newGameOnPress(ActionEvent event) {

    }

}